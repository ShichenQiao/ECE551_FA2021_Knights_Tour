var g_db_data = {"2":1,"20":1,"21":1,"22":1,"23":1,"24":1,"25":1,"26":1,"1":1};
processScopesDbFile(g_db_data);